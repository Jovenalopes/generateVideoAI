function VideoCreator({ onVideoCreate, isLoading }) {
  try {
    const [videoPrompt, setVideoPrompt] = React.useState('');
    const [videoSize, setVideoSize] = React.useState('vertical');
    const [duration, setDuration] = React.useState('5');
    const [characterCount, setCharacterCount] = React.useState(0);

    const handlePromptChange = (e) => {
      const text = e.target.value;
      if (text.length <= 500) {
        setVideoPrompt(text);
        setCharacterCount(text.length);
      }
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      if (!videoPrompt.trim()) return;

      const videoData = {
        prompt: videoPrompt,
        size: videoSize,
        duration: parseInt(duration),
        timestamp: new Date().toISOString()
      };

      onVideoCreate(videoData);
    };

    const sizes = [
      { id: 'vertical', name: 'Vertical (9:16)', desc: 'Instagram Reels, TikTok, YouTube Shorts', icon: 'smartphone' },
      { id: 'square', name: 'Square (1:1)', desc: 'Instagram Posts, Facebook', icon: 'square' },
      { id: 'horizontal', name: 'Horizontal (16:9)', desc: 'YouTube Videos, LinkedIn', icon: 'monitor' }
    ];

    const examplePrompts = [
      "A futuristic city with flying cars at sunset, cinematic style",
      "Ocean waves crashing on a rocky shore, slow motion",
      "A cat playing with colorful yarn in a cozy living room",
      "Abstract geometric shapes morphing with vibrant colors",
      "Time-lapse of flowers blooming in a garden"
    ];

    return (
      <div className="max-w-4xl mx-auto" data-name="video-creator" data-file="components/VideoCreator.js">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Crie Vídeos IA com <span className="text-gradient">Prompts Simples</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Descreva sua visão em algumas palavras e veja a IA transformá-la em um vídeo profissional
            </p>
          </div>

        <form onSubmit={handleSubmit} className="card space-y-6">
          <div>
            <label className="block text-lg font-semibold text-gray-900 mb-3">
              <div className="icon-wand-2 text-xl text-violet-500 inline mr-2"></div>
              Prompt do Vídeo
            </label>
            <textarea
              value={videoPrompt}
              onChange={handlePromptChange}
              className="input-field h-32 resize-none"
              placeholder="Descreva o vídeo que você quer criar... (máx 500 caracteres)"
              required
            />
            <div className="flex justify-between items-center mt-2">
              <p className="text-sm text-gray-500">
                Seja específico sobre visuais, estilo e atmosfera para melhores resultados
              </p>
              <span className={`text-sm font-medium ${
                characterCount > 450 ? 'text-red-500' : 'text-gray-500'
              }`}>
                {characterCount}/500
              </span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">
                <div className="icon-aspect-ratio text-xl text-cyan-500 inline mr-2"></div>
                Tamanho do Vídeo
              </label>
              <div className="space-y-3">
                {sizes.map((size) => (
                  <button
                    key={size.id}
                    type="button"
                    onClick={() => setVideoSize(size.id)}
                    className={`w-full p-3 rounded-lg border-2 transition-all text-left ${
                      videoSize === size.id
                        ? 'border-violet-500 bg-violet-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`icon-${size.icon} text-xl ${
                        videoSize === size.id ? 'text-violet-500' : 'text-gray-400'
                      }`}></div>
                      <div>
                        <div className="font-medium">{size.name}</div>
                        <div className="text-sm text-gray-500">{size.desc}</div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-3">
                <div className="icon-clock text-xl text-amber-500 inline mr-2"></div>
                Duração
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="input-field mb-4"
              >
                <option value="3">3 segundos</option>
                <option value="5">5 segundos</option>
                <option value="10">10 segundos</option>
                <option value="15">15 segundos</option>
                <option value="30">30 segundos</option>
                <option value="60">1 minuto</option>
                <option value="120">2 minutos</option>
                <option value="180">3 minutos</option>
              </select>

              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 mb-2">Prompts de Exemplo:</h4>
                <div className="space-y-2">
                  {examplePrompts.slice(0, 3).map((prompt, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => {
                        setVideoPrompt(prompt);
                        setCharacterCount(prompt.length);
                      }}
                      className="block w-full text-left text-sm text-gray-600 hover:text-violet-600 transition-colors"
                    >
                      "{prompt}"
                    </button>
                  ))}
                </div>
                
                <div className="mt-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                      <div className="icon-zap text-white text-xs"></div>
                    </div>
                    <span className="text-sm font-semibold text-purple-700">Powered by Pika.art</span>
                  </div>
                  <p className="text-xs text-purple-600">
                    IA de última geração para criar vídeos cinematográficos profissionais
                  </p>
                </div>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading || !videoPrompt.trim()}
            className="btn-primary w-full text-lg flex items-center justify-center space-x-3 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                <span>Gerando Vídeo IA...</span>
              </>
            ) : (
              <>
                <div className="icon-play text-xl"></div>
                <span>Gerar Vídeo IA</span>
              </>
            )}
          </button>
        </form>
      </div>
    );
  } catch (error) {
    console.error('VideoCreator component error:', error);
    return null;
  }
}
