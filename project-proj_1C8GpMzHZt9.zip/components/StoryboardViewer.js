function StoryboardViewer({ videoData, onGenerateVideo, onBack }) {
  try {
    const [storyboard, setStoryboard] = React.useState([]);
    const [isGenerating, setIsGenerating] = React.useState(false);

    React.useEffect(() => {
      generateStoryboard();
    }, []);

    const generateStoryboard = async () => {
      setIsGenerating(true);
      
      // Generate storyboard from prompt
      const scenes = await generateScenesFromPrompt(videoData.prompt, videoData.duration);
      setStoryboard(scenes);
      setIsGenerating(false);
    };

    const handleGenerateVideo = () => {
      onGenerateVideo();
    };

    if (isGenerating) {
      return (
        <div className="max-w-4xl mx-auto text-center" data-name="storyboard-loading" data-file="components/StoryboardViewer.js">
          <div className="card">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-violet-500 mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold mb-2">Criando storyboard...</h3>
            <p className="text-gray-600">Nossa IA está analisando seu conteúdo e criando as cenas</p>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-6xl mx-auto" data-name="storyboard-viewer" data-file="components/StoryboardViewer.js">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Storyboard Gerado</h2>
            <p className="text-gray-600">Revise as cenas antes de gerar o vídeo final</p>
          </div>
          
          <button
            onClick={onBack}
            className="btn-secondary flex items-center space-x-2"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
        </div>

        <div className="grid gap-6 mb-8">
          {storyboard.map((scene, index) => (
            <div key={index} className="card">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                    <span className="text-violet-600 font-bold">{index + 1}</span>
                  </div>
                </div>
                
                <div className="flex-grow">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Cena {index + 1}</h4>
                      <p className="text-gray-700 mb-3">{scene.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>
                          <div className="icon-clock inline mr-1"></div>
                          {scene.duration}s
                        </span>
                        <span>
                          <div className="icon-image inline mr-1"></div>
                          {scene.visualStyle}
                        </span>
                      </div>
                    </div>
                    
                    <div className="bg-gray-100 rounded-lg overflow-hidden min-h-32 relative">
                      <img 
                        src={`https://images.unsplash.com/photo-${1500000000000 + index}?w=300&h=200&fit=crop&auto=format`}
                        alt={`Cena ${index + 1}`}
                        className="w-full h-32 object-cover"
                        onError={(e) => {
                          e.target.src = `https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=300&h=200&fit=crop`;
                        }}
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                        <div className="bg-white bg-opacity-90 px-2 py-1 rounded text-xs font-medium">
                          Cena {index + 1}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="card bg-gradient-to-r from-violet-50 to-cyan-50">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Pronto para gerar o vídeo?</h3>
            <p className="text-gray-600 mb-6">
              O storyboard está completo. Agora vamos adicionar narração IA e música de fundo.
            </p>
            
            <button
              onClick={handleGenerateVideo}
              className="btn-primary text-lg flex items-center justify-center space-x-3 mx-auto"
            >
              <div className="icon-play text-xl"></div>
              <span>Gerar Vídeo Final</span>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('StoryboardViewer component error:', error);
    return null;
  }
}