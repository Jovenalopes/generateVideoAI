function VideoPreview({ videoData, onReset, onBack }) {
  try {
    const [isGenerating, setIsGenerating] = React.useState(true);
    const [videoReady, setVideoReady] = React.useState(false);
    const [isPlaying, setIsPlaying] = React.useState(false);
    const [currentTime, setCurrentTime] = React.useState(0);
    const [generationProgress, setGenerationProgress] = React.useState(0);
    const [generatedVideo, setGeneratedVideo] = React.useState(null);
    const [generationStatus, setGenerationStatus] = React.useState('Preparando...');

    React.useEffect(() => {
      generateActualVideo();
    }, []);

    const generateActualVideo = async () => {
      try {
        setGenerationStatus('Analisando prompt...');
        setGenerationProgress(10);
        
        setGenerationStatus('Gerando vídeo com IA...');
        setGenerationProgress(30);
        
        // Use enhanced generation for longer videos
        const video = videoData.duration > 30 ? 
          await generateLongVideo(videoData.prompt, videoData.size, videoData.duration) :
          await generateVideoFromPrompt(videoData.prompt, videoData.size, videoData.duration);
        
        setGenerationProgress(80);
        setGenerationStatus('Finalizando...');
        
        // Add some final processing time
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setGeneratedVideo(video);
        setGenerationProgress(100);
        setIsGenerating(false);
        setVideoReady(true);
        setGenerationStatus('Concluído!');
        
      } catch (error) {
        console.error('Video generation failed:', error);
        setGenerationStatus('Erro na geração. Usando preview...');
        setGenerationProgress(100);
        setIsGenerating(false);
        setVideoReady(true);
      }
    };

    React.useEffect(() => {
      let interval;
      if (isPlaying && videoReady) {
        interval = setInterval(() => {
          setCurrentTime(prev => {
            if (prev >= videoData.duration) {
              setIsPlaying(false);
              return 0;
            }
            return prev + 0.1;
          });
        }, 100);
      }
      return () => clearInterval(interval);
    }, [isPlaying, videoReady, videoData.duration]);

    const playVideo = () => {
      if (!videoReady) return;
      setIsPlaying(!isPlaying);
      if (currentTime >= videoData.duration) {
        setCurrentTime(0);
      }
    };

    const downloadVideo = () => {
      if (!videoReady) return;
      // Create a mock video file for download
      const link = document.createElement('a');
      link.href = 'data:text/plain;charset=utf-8,Mock Video File - ' + videoData.text.substring(0, 50);
      link.download = `video-${Date.now()}.mp4`;
      link.click();
    };

    const shareVideo = (platform) => {
      if (!videoReady) return;
      const shareText = `Criado com IA: ${videoData.text.substring(0, 100)}...`;
      const shareUrl = window.location.href;
      
      const shareUrls = {
        'Instagram': `https://www.instagram.com/`,
        'TikTok': `https://www.tiktok.com/upload`,
        'YouTube': `https://studio.youtube.com/channel/upload`
      };
      
      window.open(shareUrls[platform] || shareUrls.Instagram, '_blank');
    };

    const formatTime = (seconds) => {
      const mins = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    if (isGenerating) {
      return (
        <div className="max-w-4xl mx-auto text-center" data-name="video-generating" data-file="components/VideoPreview.js">
          <div className="card">
            <div className="mb-6">
              <div className="animate-spin rounded-full h-20 w-20 border-b-2 border-violet-500 mx-auto mb-4"></div>
              <h3 className="text-2xl font-semibold mb-2">Gerando seu vídeo...</h3>
              <p className="text-gray-600 mb-2">{generationStatus}</p>
              <p className="text-gray-600 mb-4">{Math.round(generationProgress)}% concluído</p>
              
              <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
                <div 
                  className="bg-violet-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${generationProgress}%` }}
                ></div>
              </div>
            </div>
            
            <div className="space-y-3 text-left max-w-md mx-auto">
              <div className="flex items-center space-x-3">
                <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
                  <div className="icon-check text-white text-sm"></div>
                </div>
                <span className="text-gray-700">Prompt analisado</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  generationProgress > 30 ? 'bg-green-500' : 'bg-purple-500'
                }`}>
                  {generationProgress > 30 ? (
                    <div className="icon-check text-white text-sm"></div>
                  ) : (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  )}
                </div>
                <span className="text-gray-700">Pika.art processando IA</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  generationProgress > 70 ? 'bg-green-500' : 'bg-gray-300'
                }`}>
                  {generationProgress > 70 ? (
                    <div className="icon-check text-white text-sm"></div>
                  ) : (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-violet-500"></div>
                  )}
                </div>
                <span className="text-gray-700">Renderização cinemática</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  generationProgress >= 100 ? 'bg-green-500' : 'bg-gray-300'
                }`}>
                  {generationProgress >= 100 ? (
                    <div className="icon-check text-white text-sm"></div>
                  ) : (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-violet-500"></div>
                  )}
                </div>
                <span className="text-gray-700">Vídeo finalizado</span>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="flex items-center justify-center space-x-2">
                <div className="w-5 h-5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
                <span className="text-sm font-medium text-purple-700">Pika.art AI Engine</span>
              </div>
              <p className="text-xs text-purple-600 text-center mt-1">
                Tecnologia de ponta para vídeos de alta qualidade
              </p>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="max-w-4xl mx-auto" data-name="video-preview" data-file="components/VideoPreview.js">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Seu vídeo está pronto!</h2>
            <p className="text-gray-600">Baixe ou compartilhe diretamente nas redes sociais</p>
          </div>
          
          <button
            onClick={onBack}
            className="btn-secondary flex items-center space-x-2"
          >
            <div className="icon-arrow-left text-lg"></div>
            <span>Voltar</span>
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Video Player */}
          <div className="card">
            <div 
              className="aspect-[9/16] bg-black rounded-lg mb-4 relative overflow-hidden cursor-pointer"
              onClick={playVideo}
            >
              {/* Background video content */}
              <div className="absolute inset-0">
                {generatedVideo && generatedVideo.videoUrl && generatedVideo.source !== 'Fallback' ? (
                  <video 
                    className="w-full h-full object-cover"
                    src={generatedVideo.videoUrl}
                    muted
                    loop
                    playsInline
                  />
                ) : (
                  <img 
                    src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=700&fit=crop"
                    alt="Video background"
                    className="w-full h-full object-cover"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black opacity-70"></div>
              </div>
              
              {/* Video text overlay */}
              <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-4 z-10">
                <h3 className="text-lg font-bold mb-2 bg-black bg-opacity-50 px-3 py-1 rounded">
                  {videoData.prompt.substring(0, 50)}...
                </h3>
                <p className="text-sm opacity-90 bg-black bg-opacity-30 px-2 py-1 rounded">
                  Size: {videoData.size}
                </p>
              </div>
              
              {/* Play/Pause overlay */}
              <div className="absolute inset-0 flex items-center justify-center z-20">
                {!isPlaying ? (
                  <div className="bg-black bg-opacity-60 rounded-full p-4 hover:bg-opacity-80 transition-all">
                    <div className="icon-play text-4xl text-white"></div>
                  </div>
                ) : (
                  <div className="bg-black bg-opacity-60 rounded-full p-4 hover:bg-opacity-80 transition-all">
                    <div className="icon-pause text-4xl text-white"></div>
                  </div>
                )}
              </div>
              
              {/* Progress bar */}
              <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-20 h-2 z-30">
                <div 
                  className="bg-violet-500 h-full transition-all duration-100"
                  style={{ width: `${(currentTime / videoData.duration) * 100}%` }}
                ></div>
              </div>
              
              {/* Time display */}
              <div className="absolute bottom-3 right-3 text-white text-sm bg-black bg-opacity-70 px-2 py-1 rounded z-30">
                {formatTime(currentTime)} / {formatTime(videoData.duration)}
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button 
                onClick={playVideo}
                disabled={!videoReady}
                className="flex-1 btn-primary flex items-center justify-center space-x-2 disabled:opacity-50"
              >
                <div className={`text-lg ${isPlaying ? 'icon-pause' : 'icon-play'}`}></div>
                <span>{isPlaying ? 'Pausar' : 'Reproduzir'}</span>
              </button>
              
              <button 
                onClick={downloadVideo}
                disabled={!videoReady}
                className="btn-secondary flex items-center space-x-2 disabled:opacity-50"
              >
                <div className="icon-download text-lg"></div>
                <span>Download</span>
              </button>
            </div>
          </div>

          {/* Video Info & Sharing */}
          <div className="space-y-6">
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Detalhes do Vídeo</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Formato:</span>
                  <span>MP4 (1080x1920)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duração:</span>
                  <span>{videoData.duration} segundos</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Size:</span>
                  <span className="capitalize">{videoData.size}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Criado em:</span>
                  <span>{new Date(videoData.timestamp).toLocaleDateString('pt-BR')}</span>
                </div>
                {generatedVideo && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Gerado por:</span>
                    <span className="text-green-600 font-medium">{generatedVideo.source} AI</span>
                  </div>
                )}
              </div>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Compartilhar</h3>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => shareVideo('Instagram')}
                  disabled={!videoReady}
                  className="p-3 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="icon-camera text-2xl text-pink-500 mb-1"></div>
                  <span className="text-xs">Instagram</span>
                </button>
                
                <button
                  onClick={() => shareVideo('TikTok')}
                  disabled={!videoReady}
                  className="p-3 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="icon-music text-2xl text-black mb-1"></div>
                  <span className="text-xs">TikTok</span>
                </button>
                
                <button
                  onClick={() => shareVideo('YouTube')}
                  disabled={!videoReady}
                  className="p-3 border border-gray-200 rounded-lg hover:border-gray-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="icon-video text-2xl text-red-500 mb-1"></div>
                  <span className="text-xs">YouTube</span>
                </button>
              </div>
              
              {videoReady && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-2 text-green-700">
                    <div className="icon-check-circle text-lg"></div>
                    <span className="text-sm font-medium">Vídeo pronto para compartilhar!</span>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={onReset}
              className="w-full btn-secondary flex items-center justify-center space-x-2"
            >
              <div className="icon-plus text-lg"></div>
              <span>Criar Novo Vídeo</span>
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('VideoPreview component error:', error);
    return null;
  }
}