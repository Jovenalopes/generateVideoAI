function Header() {
  try {
    return (
      <header className="bg-white shadow-sm border-b" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
                <div className="icon-video text-xl text-white"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gradient">Criador de Vídeos IA</h1>
                <p className="text-sm text-gray-600">Reels • Shorts • TikTok</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm text-gray-600">
                <div className="icon-zap text-lg text-amber-500"></div>
                <span>Powered by AI</span>
              </div>
              
              <button className="btn-secondary flex items-center space-x-2">
                <div className="icon-help-circle text-lg"></div>
                <span className="hidden md:inline">Ajuda</span>
              </button>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}